<?php
/**
 * $Id: Bar.test.php 535 2010-11-01 13:02:16Z rudisoft $
 *
 * Bar test.
 *
 * @author     Radu Maier <rudisoft@rudisoft.net>
 * @copyright  Copyright (c) 2008 - 2010, RudiSoft.Net
 * @license    http://www.opensource.org/licenses/bsd-license.php
 * @package    RudTest
 * @subpackage Misc
 * @version    $Revision: 535 $
 * @since      Version 5
 * @access     public
 * @filesource
 */

/**
 * @var int
 */
$steps = 0;

echo 'Test not implemented.';

/**
 * @var bool
 */
$continue = FALSE;
?>