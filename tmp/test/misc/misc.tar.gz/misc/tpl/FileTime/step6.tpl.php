<?php
/**
 * $Id: step6.tpl.php 535 2010-11-01 13:02:16Z rudisoft $
 *
 * Test.
 *
 * @author     Radu Maier <rudisoft@rudisoft.net>
 * @copyright  Copyright (c) 2008 - 2010, RudiSoft.Net
 * @license    http://www.opensource.org/licenses/bsd-license.php
 */
?>
<p>
	Cleanup complete ( <?php echo $time; ?> s ).
</p>

<p>
	Thank you!
</p>

<p class="next">
	&#187; <a class="cont" title="Start again" href="./index.php?step=0">Finished!</a>
</p>