<?php
/**
 * $Id: step4.tpl.php 535 2010-11-01 13:02:16Z rudisoft $
 *
 * Test.
 *
 * @author     Radu Maier <rudisoft@rudisoft.net>
 * @copyright  Copyright (c) 2008 - 2010, RudiSoft.Net
 * @license    http://www.opensource.org/licenses/bsd-license.php
 */
?>
<p>
	Test case <strong>"Filegetcontents"</strong> complete ( <?php echo $time; ?> s ).
</p>

<p class="next">
	&#187; <a class="cont" title="Go to Step 5" href="./index.php?test=<?php echo $test; ?>&amp;step=5">Go to step 5</a>
</p>