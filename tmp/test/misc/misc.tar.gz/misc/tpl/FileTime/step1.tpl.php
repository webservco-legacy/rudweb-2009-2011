<?php
/**
 * $Id: step1.tpl.php 535 2010-11-01 13:02:16Z rudisoft $
 *
 * Test.
 *
 * @author     Radu Maier <rudisoft@rudisoft.net>
 * @copyright  Copyright (c) 2008 - 2010, RudiSoft.Net
 * @license    http://www.opensource.org/licenses/bsd-license.php
 */
?>
<p>
	Test environment initialization complete ( <?php echo $time; ?> s ).
</p>

<p class="next">
	&#187; <a class="cont" title="Go to Step 2" href="./index.php?test=<?php echo $test; ?>&amp;step=2">Go to step 2</a>
</p>